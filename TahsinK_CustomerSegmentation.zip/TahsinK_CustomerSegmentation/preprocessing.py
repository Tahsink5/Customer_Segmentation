# preprocessing.py

import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler


def load_dataset(filepath):

    df = pd.read_csv(filepath)

    print("Dataset Loaded Successfully")
    print("Shape:", df.shape)

    return df


def explore_data(df):

    print("\nFirst 5 Rows")
    print(df.head())

    print("\nDataset Shape")
    print(df.shape)

    print("\nMissing Values")
    print(df.isnull().sum())

    print("\nDuplicate Rows")
    print(df.duplicated().sum())


def preprocess_data(df):

    df = df.copy()

    def spending_category(score):

        if score <= 33:
            return "Low"

        elif score <= 66:
            return "Medium"

        else:
            return "High"

    df["Spending_Category"] = df["Spending_Score"].apply(
        spending_category
    )

    encoder = LabelEncoder()

    df["Target"] = encoder.fit_transform(
        df["Spending_Category"]
    )

    print("Preprocessing Completed")

    return df, encoder


def prepare_features(df):

    clustering_features = [
        "Annual_Income",
        "Spending_Score"
    ]

    scaler_cluster = StandardScaler()

    X_cluster = scaler_cluster.fit_transform(
        df[clustering_features]
    )

    supervised_features = [
        "Annual_Income",
        "Age",
        "Purchase_Frequency"
    ]

    X = df[supervised_features]

    y = df["Target"]

    scaler_supervised = StandardScaler()

    return (
        X_cluster,
        X,
        y,
        scaler_cluster,
        scaler_supervised
    )
