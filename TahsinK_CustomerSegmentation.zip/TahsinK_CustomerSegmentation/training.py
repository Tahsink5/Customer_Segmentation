# training.py

from sklearn.cluster import KMeans
from sklearn.ensemble import RandomForestClassifier


def train_kmeans(X_cluster):

    model = KMeans(
        n_clusters=5,
        random_state=42
    )

    clusters = model.fit_predict(X_cluster)

    print("K-Means Training Completed")

    return model, clusters


def train_random_forest(X_train, y_train):

    model = RandomForestClassifier(
        n_estimators=100,
        random_state=42
    )

    model.fit(X_train, y_train)

    print("Random Forest Training Completed")

    return model