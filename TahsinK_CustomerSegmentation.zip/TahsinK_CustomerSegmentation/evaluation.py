# evaluation.py

from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    classification_report,
    silhouette_score
)


def evaluate_clustering(
    X_cluster,
    clusters
):

    score = silhouette_score(
        X_cluster,
        clusters
    )

    print("\nSilhouette Score")
    print(round(score, 4))


def evaluate_classification(
    y_test,
    y_pred
):

    accuracy = accuracy_score(
        y_test,
        y_pred
    )

    print("\nAccuracy")
    print(round(accuracy, 4))

    print("\nConfusion Matrix")
    print(
        confusion_matrix(
            y_test,
            y_pred
        )
    )

    print("\nClassification Report")
    print(
        classification_report(
            y_test,
            y_pred
        )
    )

    return accuracy